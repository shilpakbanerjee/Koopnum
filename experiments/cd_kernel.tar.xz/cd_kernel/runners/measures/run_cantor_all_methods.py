from __future__ import annotations

import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path

from experiments.cd_kernel.measures.cantor_measure import (
    cantor_measure_on_circle,
    moments_from_atomic,
)

from experiments.cd_kernel.measures.reconstruction import (
    evaluate_cd_kernel_from_moments,
)

from experiments.cd_kernel.measures.cesaro import (
    cesaro_density_from_moments,
)

from experiments.cd_kernel.measures.quadrature import (
    reconstruct_atomic_measure_from_moments,
)

OUTPUT_DIR = Path("experiments/cd_kernel/outputs/measures/cantor")
PLOT_DIR = Path("experiments/cd_kernel/plots/measures/cantor")
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
PLOT_DIR.mkdir(parents=True, exist_ok=True)


def step_cdf_on_grid(step_x, step_y, grid):
    step_x = np.asarray(step_x)
    step_y = np.asarray(step_y)
    grid = np.asarray(grid)

    idx = np.searchsorted(step_x, grid, side="right") - 1
    out = np.zeros_like(grid, dtype=float)

    mask = idx >= 0
    out[mask] = step_y[idx[mask]]

    return out


def main():
    # ---------------------------
    # Parameters
    # ---------------------------
    stage = 8              # 256 atoms
    order = 80
    grid_size = 2048

    # ---------------------------
    # Build Cantor measure
    # ---------------------------
    angles, weights = cantor_measure_on_circle(stage)

    moments = moments_from_atomic(
        angles=angles,
        weights=weights,
        order=order,
    )

    # ---------------------------
    # CD kernel
    # ---------------------------
    cd_result = evaluate_cd_kernel_from_moments(
        moments,
        order=order,
        grid_size=grid_size,
        normalize_density=True,
    )

    # ---------------------------
    # Cesàro
    # ---------------------------
    cesaro_result = cesaro_density_from_moments(
        moments,
        order=order,
        grid_size=grid_size,
        clip_negative=True,
        normalize_mass=True,
    )

    # ---------------------------
    # Quadrature
    # ---------------------------
    quad_result = reconstruct_atomic_measure_from_moments(
        moments,
        order=order,
        num_nodes=6 * (order + 1),
        mass_constraint_weight=5.0,
        normalize_mass=True,
    )

    # ---------------------------
    # Align grids
    # ---------------------------
    angles_grid = cd_result.angles

    quad_cdf_on_grid = step_cdf_on_grid(
        quad_result.cdf_grid,
        quad_result.cdf_values,
        angles_grid,
    )

    # ---------------------------
    # Plot 1: Density (WARNING: misleading)
    # ---------------------------
    plt.figure(figsize=(10, 4))
    plt.plot(angles_grid, cd_result.density_proxy, label="CD kernel")
    plt.plot(cesaro_result.angles, cesaro_result.density, label="Cesàro")

    plt.title("Cantor measure (singular continuous): density view")
    plt.xlabel("Angle")
    plt.ylabel("Density / proxy")
    plt.legend()
    plt.grid(True, alpha=0.3)

    plt.savefig(PLOT_DIR / "cantor_density.png", dpi=150)

    # ---------------------------
    # Plot 2: CDF (THIS IS KEY)
    # ---------------------------
    plt.figure(figsize=(10, 4))

    plt.plot(
        cesaro_result.angles,
        cesaro_result.cdf,
        label="Cesàro CDF",
        linewidth=1.5,
    )

    plt.step(
        angles_grid,
        quad_cdf_on_grid,
        where="post",
        label="Quadrature CDF",
        linewidth=1.4,
    )

    plt.title("Cantor measure: CDF comparison (correct viewpoint)")
    plt.xlabel("Angle")
    plt.ylabel("CDF")
    plt.legend()
    plt.grid(True, alpha=0.3)

    plt.savefig(PLOT_DIR / "cantor_cdf.png", dpi=150)

    plt.show()

    # ---------------------------
    # Save data
    # ---------------------------
    np.savez(
        OUTPUT_DIR / "cantor_results.npz",
        moments=moments,
        cd_density=cd_result.density_proxy,
        cesaro_density=cesaro_result.density,
        cesaro_cdf=cesaro_result.cdf,
        quad_nodes=quad_result.node_angles,
        quad_weights=quad_result.weights,
        quad_cdf_grid=quad_result.cdf_grid,
        quad_cdf_values=quad_result.cdf_values,
    )

    print("\nDone: Cantor benchmark (singular continuous)")
    print(f"Stage = {stage}, atoms = {2**stage}")


if __name__ == "__main__":
    main()